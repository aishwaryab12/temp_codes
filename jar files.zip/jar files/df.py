from random import sample
import random

def random_prime():
	primes=[]
	
	for num in range(1,50):
		if(num>1):
			for i in range(2,num):
				if(num%i) ==0 :
					break
			else:
				primes.append(num)
	
	primes=set(primes)
	l=sample(primes,1)
	return l[0]

#Function to find primitive root of p
def primitive_root_of_p(p):
	L=list(range(1,p))
	P_L=[]
	primitve_roots=[]
	for g in range(1,p):
		for n in range(1,p):

			P_L.append(g**n%p)

		P_L=set(P_L)
		P_L=list(P_L)
		P_L.sort()
	
		if L == P_L:
			primitve_roots.append(g)

		P_L.clear()
		print(primitve_roots)
	return random.choice(primitve_roots)


#p=int(input("Enter the value of p : "))
p=random_prime()
#p=23
print(" p: ",p)
#primitive root
g=primitive_root_of_p(p)
#g=5
print("Primitive Root of p : ",g)

#User A private Key
X_A=int(input("Enter private key of A :"))

#User A public Key
Y_A = g ** X_A % p 

#User B private Key
X_B=int(input("Enter private key of B :"))

#User B public Key
Y_B = g ** X_B % p 

#Secret Key genaretion at A
secret_A = Y_B**X_A % p

#Secret Key genaretion at B
secret_B = Y_A**X_B % p

print("\nUser A Private Key(X_A < q) :",X_A)
print("User A Public Key :",Y_A)

print("\nUser B Private Key(X_B < q) :",X_B)
print("User B Public Key :",Y_B)

print("\nSecret Key at User A : ",secret_A)
print("\nSecret Key at User B : ",secret_B)


    

