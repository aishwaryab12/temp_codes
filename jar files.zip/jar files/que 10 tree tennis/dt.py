# sudo apt-get install python3-pygraphviz
#python3 -m pip install graphviz
#sudo apt-get install graphviz	
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix 
from sklearn import tree
from sklearn import preprocessing
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report  
columns=['OutLook','Temp','Humidity','Wind']
# high=0,low=1,medium=2,male=1.female=0,single=1,married=0
tennis_data = pd.read_csv('tennis.csv',sep= ',', header= None)



le = preprocessing.LabelEncoder()
list1=[]
print("\n----original dataset----\n\n")
print(tennis_data)
for i in range(5):
	tennis_data.values[:,i] = le.fit_transform(tennis_data.values[:,i])
	list1.append(le.classes_)
print ("\nDataset Lenght::", len(tennis_data))
print ("\nDataset Shape::", tennis_data.shape)


	
X = tennis_data.values[:, 1:5] 
Y = tennis_data.values[:, 5] 
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.3, random_state = 3) 

print("\n----Encoded data----\n\n")
print(X)
print(Y)

	
clf = DecisionTreeClassifier(criterion='entropy')
clf.fit(X, Y)
print("\n----Test samples----\n")
print(X_test)
y_predicted = clf.predict(X_test) 


print("\n----predicted output----\n")
print(y_predicted)

print("\nConfusion Matrix:\n")
print(confusion_matrix(y_test,y_predicted)) 
print ("\nAccuracy :\n")
print(accuracy_score(y_test,y_predicted)*100) 
print("Report : \n")
print(classification_report(y_test,y_predicted)) 


age=list1[1].tolist().index('Sunny')
income=list1[2].tolist().index('Mild')
gender=list1[3].tolist().index('Normal')
status=list1[4].tolist().index('Strong')
y_predicted=clf.predict([[age,income,gender,status]])

print("prediction for given query is :\n ")
print(y_predicted)
import graphviz 
dot_data = tree.export_graphviz(clf, out_file=None,feature_names=columns,class_names=['Yes','No']) 
graph = graphviz.Source(dot_data) 
graph.render("cos") 
