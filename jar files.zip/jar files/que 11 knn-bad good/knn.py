import numpy as np  
import matplotlib.pyplot as plt  
import pandas as pd 
url = "data.csv"

# Assign colum names to the dataset
names = ['x', 'y', 'class']

# Read dataset to pandas dataframe
dataset = pd.read_csv(url, names=names) 
 
X = dataset.iloc[:, :-1].values  
Y = dataset.iloc[:, 2].values 


from sklearn.neighbors import KNeighborsClassifier  
classifier = KNeighborsClassifier(n_neighbors=3)  
classifier.fit(X, Y) 
y_pred = classifier.predict([[3,7]])
print("\nx_text \n")
print("[3,7]")  
print("\ny_pred \n")
print(y_pred)


error = []

# Calculating error for K values between 1 and 5
for i in range(1, 4):  
    knn = KNeighborsClassifier(n_neighbors=i)
    knn.fit(X,Y)
    pred_i = knn.predict(X)
    error.append(np.mean(pred_i != Y))

  
plt.plot(range(1, 4), error, color='red', marker='o')
plt.title('Error Rate K Value')  
plt.xlabel('K Value')  
plt.ylabel('Mean Error') 
plt.show() 
