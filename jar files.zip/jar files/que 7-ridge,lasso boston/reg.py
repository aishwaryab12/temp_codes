import numpy as np
import matplotlib.pyplot as plt 

import pandas as pd  
import seaborn as sns

from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
boston_dataset = load_boston()
boston = pd.DataFrame(boston_dataset.data, columns=boston_dataset.feature_names)
boston['PRICE'] = boston_dataset.target
print(boston_dataset.DESCR)
print(boston.head())

X = boston.drop('PRICE', axis = 1)
Y = boston['PRICE']
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2, random_state=5)
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.metrics import accuracy_score
lm = LinearRegression()
lm.fit(X_train, Y_train)
m=lm.coef_[0]
b=lm.intercept_
print ("slope=",m)
print ("intercept=",b)
print("equation of best line of fit is y=%fm+%f")%(m,b)
Y_pred = lm.predict(X_test)
df = pd.DataFrame({'Actual': Y_test, 'Predicted': Y_pred})  
print(df)
plt.scatter(Y_test, Y_pred)
plt.xlabel("Prices: $Y_i$")
plt.ylabel("Predicted prices: $\hat{Y}_i$")
plt.title("Prices vs Predicted prices: $Y_i$ vs $\hat{Y}_i$")
plt.show()



# model evaluation for testing set

rmse = (np.sqrt(mean_squared_error(Y_test, Y_pred)))
r2 = r2_score(Y_test, Y_pred)
print("\nThe model performance for training set")
print("--------------------------------------\n")
from sklearn.model_selection import cross_val_score
scores = cross_val_score(lm, X_train, Y_train, cv=5)
print("cross validation score ")
print(scores)
print('RMSE is {}'.format(rmse))
print('R2 score is {}'.format(r2))
print("\n")


from sklearn.linear_model import Ridge
clf = Ridge(alpha=10)
clf.fit(X_train, Y_train)
y_pred=clf.predict(X_test)
rmse = (np.sqrt(mean_squared_error(Y_test, y_pred)))
r2 = r2_score(Y_test, y_pred)
print("\nThe model performance for ridge")
print("--------------------------------------\n")
from sklearn.model_selection import cross_val_score
scores = cross_val_score(clf, X_train, Y_train, cv=5)
print("cross validation score ")
print(scores)
print('RMSE is {}'.format(rmse))
print('R2 score is {}'.format(r2))
print("\n")


from sklearn.linear_model import Lasso
clf = Lasso(alpha=0.1)
clf.fit(X_train, Y_train)
y_pred=clf.predict(X_test)
rmse = (np.sqrt(mean_squared_error(Y_test, y_pred)))
r2 = r2_score(Y_test, y_pred)
print("\nThe model performance for ridge")
print("--------------------------------------\n")
from sklearn.model_selection import cross_val_score
scores = cross_val_score(clf, X_train, Y_train, cv=5)
print("cross validation score ")
print(scores)
print('RMSE is {}'.format(rmse))
print('R2 score is {}'.format(r2))
print("\n")

