import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
from sklearn.cluster import KMeans


X=np.array([[0.1,0.6],[0.15,0.71],[0.08,0.9],[0.16, 0.85],[0.2,0.3],[0.25,0.5],[0.24,0.1],[0.3,0.2]])

kmeans=KMeans(n_clusters=2,init=np.array([[0.1,0.6],[0.3,0.2]]),n_init=1)
kmeans.fit(X)

print(kmeans.labels_)

print("\nWhich cluster does P6 belongs to? -> \n")
print(kmeans.predict([[0.25,0.5]]))
print("\nWhat is the population of cluster around m2?->\n")
print(Counter(kmeans.labels_)[1]) #imp
print("\nWhat is updated value of m1 and m2? ->")
print("\n\tUpadated value of m1 ->",kmeans.cluster_centers_[0])
print("\n\tUpadated value of m2 ->",kmeans.cluster_centers_[1])
plt.scatter(X[:,0],X[:,1],c=kmeans.labels_) #imp
plt.scatter(kmeans.cluster_centers_[:,0],kmeans.cluster_centers_[:,1],color='red') #imp
plt.show()

#Elbow method to find best value of k
cost=[]
k=range(1,8)
for i in k:
	KM=KMeans(n_clusters=i)
	KM.fit(X)
	cost.append(KM.inertia_)

plt.plot(k,cost,color='g',linewidth=2)
plt.title("Elbow Method to find optimal value of K")
plt.xlabel("Value of K")	
plt.ylabel("Squared sum of instances")
plt.show()
