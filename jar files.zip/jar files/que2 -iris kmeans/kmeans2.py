import pandas as pd
import matplotlib.pyplot as plt	
from sklearn.cluster import KMeans
dataset=pd.read_csv("iris.csv")

X=dataset.iloc[:,0:4].values


#Elbow Method to find optimal value of k 
cost=[]
k=range(1,20)
for i in k:
	KM=KMeans(n_clusters=i)
	KM.fit(X)
	cost.append(KM.inertia_)

plt.plot(k,cost,color='g',linewidth='2')
plt.show()
  
kmeans=KMeans(n_clusters=3)
y_kmeans = kmeans.fit_predict(X)

#Visualising the clusters
plt.scatter(X[y_kmeans == 0, 0], X[y_kmeans == 0, 1],  c = 'red', label = 'Iris-setosa')
plt.scatter(X[y_kmeans == 1, 0], X[y_kmeans == 1, 1],  c = 'blue', label = 'Iris-versicolour')
plt.scatter(X[y_kmeans == 2, 0], X[y_kmeans == 2, 1],  c = 'green', label = 'Iris-virginica')

#Plotting the centroids of the clusters
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:,1], c = 'yellow', label = 'Centroids')
plt.legend()
plt.show()


