import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

dataset=pd.read_csv("km4.csv")
X=dataset.iloc[:,1:].values


cost=[]
k=range(1,8)
for i in k:
	KM=KMeans(n_clusters=i)
	KM.fit(X)
	cost.append(KM.inertia_)

plt.plot(k,cost,color='g',linewidth='2')
plt.title("Elbow method to find optimal value of k")
plt.xlabel("Value of k")
plt.ylabel("Squared sum of instances")
plt.show()

print("\nObeserved optimal value of k 2")

kmeans=KMeans(n_clusters=2)
kmeans.fit(X)

plt.scatter(X[:,0],X[:,1],c=kmeans.labels_,cmap='rainbow')
plt.scatter(kmeans.cluster_centers_[0],kmeans.cluster_centers_[1],label='Centriod',color='black')
plt.legend()
plt.show()

