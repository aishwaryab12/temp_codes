import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score

dataset=pd.read_csv('ass2.csv')
x=dataset.iloc[:,:-1].values
y=dataset.iloc[:,1].values

#x=[[10],[9],[2],[15],[10],[16],[11],[16]]
#y=[95,80,10,50,45,98,38,93]

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=4)


from sklearn.linear_model import LinearRegression
regressor=LinearRegression()
regressor.fit(x_train,y_train)

m=regressor.coef_
b=regressor.intercept_
print ("slope=",m)
print ("intercept=",b)

y_pred=regressor.predict(x_test)

print("Mean squared error: %.2f" % mean_squared_error(y_test, y_pred))

# Explained variance score: 1 is perfect prediction
print('Variance score: %.2f' % r2_score(y_test, y_pred))

#ridge 
from sklearn.linear_model import Ridge 
ridgeReg = Ridge(alpha=0.05, normalize=True)
ridgeReg.fit(x_train,y_train)
pred = ridgeReg.predict(x_test)
print("Mean squared error with ridge: %.2f" % mean_squared_error(y_test,pred))

#lasso
from sklearn.linear_model import Lasso
lassoReg = Lasso(alpha=0.3, normalize=True)
lassoReg.fit(x_train,y_train)
pred1 = lassoReg.predict(x_test)
print("Mean squared error with lasso: %.2f" % mean_squared_error(y_test,pred1))

plt.scatter(x_train, y_train, color = 'red')
#plt.scatter(x,y,color='red')
#plt.scatter(x_train, regressor.predict(x_train), color = 'green')
#plt.plot(x_train, regressor.predict(x_train), color = 'blue')
plt.plot(x_train, regressor.predict(x_train), color = 'blue')
plt.title('Regression')
plt.xlabel('no of hrs')
plt.ylabel('risk score')
plt.show()


from sklearn.preprocessing import PolynomialFeatures 
  
poly = PolynomialFeatures(degree = 4) 
X_poly = poly.fit_transform(x_train) 
  
poly.fit(X_poly, y_train) 
lin2 = LinearRegression() 
lin2.fit(X_poly, y_train)
 
plt.scatter(x_train, y_train, color = 'blue') 
  
plt.plot(x_train, lin2.predict(poly.fit_transform(x_train)), color = 'red') 
plt.title('Polynomial Regression') 
plt.xlabel('no of hrs') 
plt.ylabel('risk score') 
  
plt.show() 


