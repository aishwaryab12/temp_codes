import math
from random import sample

def randomPrime():
	primes=[]
	for num in range(1,50):
	   if num > 1:
	   	for i in range(2,num):
	   		if (num % i) == 0:
	   			break
	   	else:
	   		primes.append(num)
	
	primes=set(primes)
	print(primes)
	l=sample(primes,2)

	return l[0],l[1]
	
		

def calculate_e(phi_of_n):
	for i in range(phi_of_n):
		if(math.gcd(i,phi_of_n)==1 and i<phi_of_n):
			e=i
	
	return e		


def calculate_d(e,phi_of_n):
	i=1
	while (phi_of_n*i+1) % e !=0:
		i+=1
	d=(phi_of_n*i+1) // e
	return d
	'''for i in range(phi_of_n):
		if (i*e)%phi_of_n==1:
			return i'''


#STEP-1 -> Generation of p and q

#p,q = randomPrime()
p=3
q=11
print("Value of p :",p)
print("Value of q :",q)

#STEP-2 -> Calculate n
n = p*q

#STEP-3 -> Calculate phi of n
phi_of_n=(p-1)*(q-1)

#STEP-4 -> Calculate e

#e=calculate_e(phi_of_n)
e=7
print("Value of e :",e)

#STEP-5 -> Calculate d
d=calculate_d(e,phi_of_n)

print("Value of d :",d)

M=int(input("Enter plain text :"))

#Encryption
cipher_text=(M**e) % n

print("Cipher Text :",cipher_text)

plain_text=(cipher_text**d) % n

#Decryption
print("Decrypted cipher text :",plain_text)

















