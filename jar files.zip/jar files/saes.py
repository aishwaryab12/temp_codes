def RotNib(w):
	L=w[4: ]
	R=w[0:4]

	return L,R

def SubNib(b):

	sbox={'0000':'1001','0001':'0100','0010':'1010','0011':'1011',
      '0100':'1101','0101':'0001','0110':'1000','0111':'0101',
      '1000':'0110','1001':'0010','1010':'0000','1011':'0011',
      '1100':'1100','1101':'1110','1110':'1111','1111':'0111'}
	return list(sbox[b])  

def xor_operation(a,b):
	xor=[]
	i=0
	while i< len(b):
		if (a[i]=='1' and b[i]=='1'):
			xor.append('0')
		elif (a[i]=='0' and b[i]=='0'):
			xor.append('0')
		else:
			xor.append('1')		
		i=i+1	 
	return xor

def multiplication(M,S):

	st="0123456789abcdef"

	loookUpTable= [		[0, 0, 0, 0, 0, 0, 0, 0, 0, 0,   0,   0,   0,   0,   0,   0],
	        			[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf], 
	        			[0, 2, 4, 6, 8, 0xa, 0xc, 0xe, 3, 1, 7, 5, 0xb, 9, 0xf, 0xd],
	        			[0, 3, 6, 5, 0xc, 0xf, 0xa, 9, 0xb, 8, 0xd, 0xe, 7, 4, 1, 2],
	        			[0, 4, 8, 0xc, 3, 7, 0xb, 0xf, 6, 2, 0xe, 0xa, 5, 1, 0xd, 9],
	        			[0, 5, 0xa, 0xf, 7, 2, 0xd, 8, 0xe, 0xb, 4, 1, 9, 0xc, 3, 6],
	        			[0, 6, 0xc, 0xa, 0xb, 0xd, 7, 1, 5, 3, 9, 0xf, 0xe, 8, 2, 4],
	        			[0, 7, 0xe, 9, 0xf, 8, 1, 6, 0xd, 0xa, 3, 4, 2, 5, 0xc, 0xb],
	       	 			[0, 8, 3, 0xb, 6, 0xe, 5, 0xd, 0xc, 4, 0xf, 7, 0xa, 2, 9, 1],
	        			[0, 9, 1, 8, 2, 0xb, 3, 0xa, 4, 0xd, 5, 0xc, 6, 0xf, 7, 0xe],
	        			[0, 0xa, 7, 0xd, 0xe, 4, 9, 3, 0xf, 5, 8, 2, 1, 0xb, 0xc, 6],
	        			[0, 0xb, 5, 0xe, 0xa, 1, 0xf, 4, 7, 0xc, 2, 9, 0xd, 6, 8, 3],
	        			[0, 0xc, 0xb, 7, 5, 9, 0xe, 2, 0xa, 6, 1, 0xd, 0xf, 3, 4, 8],
	        			[0, 0xd, 9, 4, 1, 0xc, 8, 5, 2, 0xf, 0xb, 6, 3, 0x3, 0xa, 7],
	        			[0, 0xe, 0xf, 1, 0xd, 3, 2, 0xc, 9, 7, 6, 8, 4, 0xa, 0xb, 5],
	        			[0, 0xf, 0xd, 2, 9, 6, 4, 0xb, 1, 0xe, 0xc, 3, 8, 7, 5, 0xa]
			  	  ]

	if(M == '1'):
		return list(S)

	else:
		ss = str(hex(int(S,2))[2:])
		no=str(bin(loookUpTable[st.index(M)][st.index(ss)])[2:])
		if(len(no)==3):
			no = '0'+no
		return list(no)			  	  

			  	  
msg=list(input("Enter 16-bit plaintext :"))
key=list(input("Enter 16-bit key :"))

#----------------------------Key Generation-------------------------------------------
w0=key[ :8]
w1=key[8: ]

L,R=RotNib(w1)

w2=xor_operation(w0,xor_operation(list('10000000'),SubNib(''.join(L))+SubNib(''.join(R))))

w3=xor_operation(w2,w1)

w3_L,w3_R=RotNib(w3)

w4=xor_operation(w2,xor_operation(list('00110000'),SubNib(''.join(w3_L))+SubNib(''.join(w3_R))))

w5=xor_operation(w4,w3) 

key0=w0+w1
key1=w2+w3
key2=w4+w5

#------------------------------Encryption-----------------------------------------------

#add round-0 key to plaintext

msg=xor_operation(msg,key0)

msg0=msg[ :4]
msg1=msg[4:8]
msg2=msg[8:12]
msg3=msg[12:]

#sbox subtitution
msg0=SubNib(''.join(msg0))
msg1=SubNib(''.join(msg1))
msg2=SubNib(''.join(msg2))
msg3=SubNib(''.join(msg3))

#swapping 2nd and 4th nibble
temp=msg1
msg1=msg3
msg3=temp

#---------------------Matrix Multiplication---------------------------- 
M=[['1','4'],['4','1']]

S=[[''.join(msg0),''.join(msg1)],[''.join(msg2),''.join(msg3)]]

S00 = xor_operation( multiplication(M[0][0],S[0][0]) , multiplication(M[1][0],S[1][0]) )
S10 = xor_operation( multiplication(M[0][1],S[0][0]) , multiplication(M[1][1],S[1][0]) )
S01= xor_operation( multiplication(M[0][0],S[0][1]) , multiplication(M[1][0],S[1][1]) )
S11 = xor_operation( multiplication(M[0][1],S[0][1]) , multiplication(M[1][1],S[1][1]) )

output = S00 + S10 + S01 + S11

#-------------------------Adding round 1 key--------------------------
output = xor_operation(output,key1)

msg0=output[ :4]
msg1=output[4:8]
msg2=output[8:12]
msg3=output[12:]

#-------------------------sbox subtitution------------------------------
msg0=SubNib(''.join(msg0))
msg1=SubNib(''.join(msg1))
msg2=SubNib(''.join(msg2))
msg3=SubNib(''.join(msg3))

output = msg0 + msg1 + msg2 + msg3

#-----------------------------Adding Round 2 key--------------------------
output = xor_operation(output,key2)


print("\n\nPlain Text : "+''.join(msg))
print("\nKey : "+''.join(key))
print("\nCipher Text  :"+''.join(output))


