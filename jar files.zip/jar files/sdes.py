

def apply_p10_table(key):
	p10=[3,5,2,7,4,10,1,9,8,6]
	key1=[]
	for i in p10:
		key1.append(key[i-1])

	return key1	

def leftShift(k,n):
	key=[]
	for i in range(n):
		key.append(k[(i+1)%n])
	return key	

def apply_p8_table(key):
	p8=[6,3,7,4,8,5,10,9]
	key1=[]
	for i in p8:
		key1.append(key[i-1])

	return key1

def apply_ip8_table(msg):
	ip8=[2,6,3,1,4,8,5,7]
	msg1=[]
	for i in ip8:
		msg1.append(msg[i-1])
	return msg1	

def apply_EP_table(msg):
	ep=[4,1,2,3,2,3,4,1]
	msg1=[]
	for i in ep:
		msg1.append(msg[i-1])
	return msg1

def xor_operation(a,b):
	xor=[]
	i=0
	while i< len(b):
		if (a[i]=='1' and b[i]=='1'):
			xor.append('0')
		elif (a[i]=='0' and b[i]=='0'):
			xor.append('0')
		else:
			xor.append('1')		
		i=i+1	 
	return xor		

def apply_s_table(S,H):
	s_row=list(map(int,H[0]+H[3]))
	s_column=list(map(int,H[1]+H[2]))

	row=0
	for i in s_row:
		row= 2*row + i

	column=0
	for i in s_column:
		column= 2*column + i

	return S[row][column]

def apply_p4_table(s_out):
	list1=[]
	p4=[2,4,3,1]
	for i in p4:
		list1.append(s_out[i-1])
	return list1

def apply_ip_inverse_table(msg):
	msg1=[]
	ip_inverse=[4,1,3,5,7,2,8,6]
	for i in ip_inverse:
		msg1.append(msg[i-1])
	return msg1	

def major_step_one(msg,key,flag):
	#during K2 avoid this step
	if flag==0:
		msg=apply_ip8_table(msg)
		str=''.join(msg)
		print("\nafter applying ip-8 table :",str)

	L_msg = msg[0:4]
	R_msg = msg[4:8 ]
	str=''.join(L_msg)
	print("\nleft half :",str)
	str=''.join(R_msg)
	print("\nright half :",str)

	ep=apply_EP_table(R_msg)
	str=''.join(ep)
	print("\nafter applying EP table :",str)

	xor=xor_operation(ep,key)
	str=''.join(xor)
	print("\nafter XOR :",str)

	L=xor[0:4]

	R=xor[4:8]
	

	s0=[['01','00','11','10'],[	'11','10','01','00'],['00','10','01','11'],['11','01','11','10']]
	s1=[['00','01','10','11'],['10','00','01','11'],['11','00','01','00'],['10','01','00','11']]
	
	s_out=list(apply_s_table(s0,L)+apply_s_table(s1,R))
	str=''.join(s_out)
	print("\nafter applying s tables :",str)

	p4_out=apply_p4_table(s_out)
	str=''.join(p4_out)
	print("\nafter applying p4 tables :",str)

	xor=xor_operation(L_msg,p4_out)
	str=''.join(xor)
	print("\nafter XOR :",str)

	op=xor+R_msg
	str=''.join(op)
	print("\nafter adding xor output and right half :",str)
	
	L=op[0:4]
	R=op[4:8]
	
	## during K2 avoid this step
	if flag ==0:
		T=L
		L=R
		R=T

	return L+R
	
#Start of code

#Step 1
msg=input("\nEnter 8-bit plaintext message: ")
key=input("\nEnter 10-bit Key: ")

#Step 2
p10_key=apply_p10_table(key)
str=''.join(p10_key)
print("\nafter applying p-10 table :",str)

#Step 3
L_Key=p10_key[0:5]
R_Key=p10_key[5: ]

str=''.join(L_Key)
print("\nleft half :",str)
str=''.join(R_Key)
print("\nright half :",str)

#Step 4
L_Key=leftShift(L_Key,5)
R_Key=leftShift(R_Key,5)
str=''.join(L_Key)
print("\nleft half after shift :",str)
str=''.join(R_Key)
print("\nright half after shift :",str)
#Step 5
new_key=L_Key+R_Key
K1=apply_p8_table(new_key)
str=''.join(K1)
print("\nk1=",str)
#Step 6
L_Key=leftShift(leftShift(L_Key,5),5)
R_Key=leftShift(leftShift(R_Key,5),5)
str=''.join(L_Key)
print("\nleft half :",str)
str=''.join(R_Key)
print("\nright half :",str)
new_key = L_Key+R_Key

#Step 7
K2=apply_p8_table(new_key)
str=''.join(K2)
print("\nk2=",str)
#Encryption Process

op=major_step_one(msg,K1,0)

op1=major_step_one(op,K2,1)

list=apply_ip_inverse_table(op1)
str=''.join(list)
	
print("\n\n=============================================")

print("\nPlain Text :"+msg)
print("\nKey :"+key)
print("\nCipher Text :"+str)


